#ifndef CAPTONES_H
#define CAPTONES_H

#include "Demo.h"

////////////////////////////////////////////////////////////////////////////
// Circuit Playground Capacitive Music Keyboard
//
// Play a tone for each touch pad.
// Using 4th octave note frequencies, to nearest 1Hz.
// https://www.seventhstring.com/resources/notefrequencies.html
//  
// Author: Carter Nelson
// MIT License (https://opensource.org/licenses/MIT)
// Modified by Derrick Kikuchi, Reach and Teach to add pixel lights on each note

#define CAP_THRESHOLD   80 

uint8_t pads[] = {3, 2, 0, 1, 12, 6, 9, 10};
uint8_t numberOfPads = sizeof(pads)/sizeof(uint8_t);

////////////////////////////////////////////////////////////////////////////
void takeAction(uint8_t pad) {
  Serial.print("PAD "); Serial.print(pad); Serial.print(" playing note: ");
  switch (pad) {
    case 3:
      Serial.println("C");
      CircuitPlayground.setPixelColor(0, CircuitPlayground.colorWheel(0));
      CircuitPlayground.playTone(262, 100, false);
      break;
    case 2:
      Serial.println("D");
      CircuitPlayground.setPixelColor(1, CircuitPlayground.colorWheel(255/8));
      CircuitPlayground.playTone(294, 100, false);
      break;
    case 0:
      Serial.println("E");
      CircuitPlayground.setPixelColor(3, CircuitPlayground.colorWheel(255/8*2));
      CircuitPlayground.playTone(330, 100, false);
      break;
    case 1:
      Serial.println("F");
      CircuitPlayground.setPixelColor(4, CircuitPlayground.colorWheel(255/8*3));
      CircuitPlayground.playTone(349, 100, false);
      break;
    case 12:
      Serial.println("G");
      CircuitPlayground.setPixelColor(5, CircuitPlayground.colorWheel(255/8*4));
      CircuitPlayground.playTone(392, 100, false);
      break;
    case 6:
      Serial.println("A");
      CircuitPlayground.setPixelColor(6, CircuitPlayground.colorWheel(255/8*5));
      CircuitPlayground.playTone(440, 100, false);
      break;
    case 9:
      Serial.println("B");
      CircuitPlayground.setPixelColor(8, CircuitPlayground.colorWheel(255/8*6));
      CircuitPlayground.playTone(494, 100, false);
      break;
    case 10:
      Serial.println("C");
      CircuitPlayground.setPixelColor(9, CircuitPlayground.colorWheel(255/8*7));
      CircuitPlayground.playTone(523, 100, false);
      break;
    default:
      Serial.println("THIS SHOULD NEVER HAPPEN.");
  }
}

////////////////////////////////////////////////////////////////////////////
boolean capButton(uint8_t pad) {
  // Check if capacitive touch exceeds threshold.
  int icap=CircuitPlayground.readCap(pad);
  if (icap>20){Serial.println(icap);}
  if (icap > CAP_THRESHOLD) {
    return true;  
  } else {
    return false;
  }
}

////////////////////////////////////////////////////////////////////////////

class CapTones: public Demo {
public:
  CapTones() {}
  ~CapTones() {}

  virtual void loop() {
    CircuitPlayground.clearPixels();
    // Loop over every pad.
    for (int i=0; i<numberOfPads; i++) {
      
      // Check if pad is touched.
      if (capButton(pads[i])) {
        
        // Do something.
        takeAction(pads[i]);
      }
    }
  }

  virtual void setup(){
    CircuitPlayground.redLED(LOW);
    pinMode(6, INPUT); // ensure that inputs that are sometimes outputs are reset
    pinMode(12, INPUT);
  }
  
  virtual void modePress() {
  }

};

#endif
