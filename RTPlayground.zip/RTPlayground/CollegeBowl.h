#ifndef COLLEGEBOWL_H
#define COLLEGEBOWL_H

#include "Demo.h"
#define CAP_THRESHOLD   80 

class CollegeBowl: public Demo {
public:
  CollegeBowl() {buttonArmed=false;}
  ~CollegeBowl() {}

  virtual void loop() {
    bool player1, player2;
    if (firstTime){
      CircuitPlayground.clearPixels();
      firstTime=false;
    }
    // Check if pad #3 is touched.
    if (buttonArmed){
      CircuitPlayground.clearPixels();
      CircuitPlayground.redLED(HIGH); 
      if (millis() % 2 ==0) { // use even/odd test of timer to give equal chance to button 3 and button 10
        if (capButton(3)) { // if player 1 hits button first, go red team
          Serial.println("Red Team");
          contactHit(255,0,0);
          buttonArmed=false;
        } else {
            if (capButton(10)) { // if player 2 hits button first, go blue team
              Serial.println("Blue Team");
              contactHit(0,0,255);
              buttonArmed=false;
            } 
        }        
      }  else {
          if (capButton(10)) { // if player 2 hits button first, go blue team
            Serial.println("Blue Team");
            contactHit(0,0,255);
            buttonArmed=false;
          } else {
              if (capButton(3)) { // if player 1 hits button first, go red team
                Serial.println("Red Team");
                contactHit(255,0,0);
                buttonArmed=false;
                CircuitPlayground.clearPixels();
              }
          }     
      }    
    } else { // don't poll buttons until left button arms the buttons
      //CircuitPlayground.clearPixels();
      CircuitPlayground.redLED(LOW);      
      if (CircuitPlayground.leftButton() && !capButton(3)&& !capButton(10) ) { // won't arm if buttons are pushed
        buttonArmed=true;
        CircuitPlayground.redLED(HIGH);
        for (uint8_t i=0;i<10;i++) {
          CircuitPlayground.setPixelColor(i,0,255,0);
        }
        delay(10);
        CircuitPlayground.clearPixels();
      }     
    }
  }

  virtual void setup(){
    buttonArmed=true;
    firstTime=true;
    CircuitPlayground.redLED(LOW);
  }
  
  virtual void modePress() {
  }

private:
int score;
bool buttonArmed;
bool firstTime;

};


#endif
