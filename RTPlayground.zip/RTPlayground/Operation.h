#ifndef OPERATION_H
#define OPERATION_H

#include "Demo.h"

#define NOTE_SHORT 150
#define NOTE_LONG 450

#define CAP_THRESHOLD   80 


void dispScore(uint8_t score){
    // Light up current score in green leds
    for (int i=0; i<10; ++i) {
      CircuitPlayground.strip.setPixelColor(i,0);
    }    
    for (int i=0; i<score; ++i) {
      CircuitPlayground.strip.setPixelColor(i,0,255,0);
    }
    CircuitPlayground.strip.show();
}

void playNote(int freq,int duration){
  CircuitPlayground.playTone(freq,duration);
  delay(.3*duration);
}
void failTone(){
  playNote(330,NOTE_SHORT);
  playNote(330,NOTE_SHORT);
  playNote(330,NOTE_SHORT);
  playNote(262,NOTE_LONG);
  playNote(294,NOTE_SHORT);
  playNote(294,NOTE_SHORT);
  playNote(294,NOTE_SHORT);
  playNote(247,NOTE_LONG);
}

class Operation: public Demo {
public:
  Operation() { score=10; }
  ~Operation() { }

  virtual void loop() {
    dispScore(score);
    // Check if pad #3 is touched.
    if (capButton(3)) { 
      Serial.println("Ouch!");
      score--;
      Serial.print(score); Serial.println(" lives left.");
      dispScore(score);
      CircuitPlayground.playTone(523, 100, false);
      delay(250);
    }
    //check if out of lives
    if (score<=0){
      for (int i=0; i<10; ++i) {
        CircuitPlayground.setPixelColor(i,255,0,0);
      }
      Serial.println("Out of lives!");
      failTone();
      delay(2000);
      score=10;
      Serial.println("Reset to 10 lives.");
    }
  }

  virtual void setup(){
    score=10;
    CircuitPlayground.redLED(LOW);
  }
  
  virtual void modePress() {

  }

private:
int score;  
};


#endif
