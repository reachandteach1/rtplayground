#ifndef LIGHTTAG1_H
#define LIGHTTAG1_H

#include "Demo.h"
#include <Servo.h>


void showTarget(){
  for (uint8_t i=0;i<10;i++){
    CircuitPlayground.strip.setPixelColor(i,0,0,0);
  }
  CircuitPlayground.strip.setPixelColor(1,0,0,255);
  CircuitPlayground.strip.show();
}

void hideTarget(){
  for (uint8_t i=0;i<10;i++){
    CircuitPlayground.strip.setPixelColor(i,0,0,0);
  }
  CircuitPlayground.strip.show();
}

class LightTag1: public Demo {
public:
  LightTag1() { }
  ~LightTag1() {}

  virtual void loop() {
    if (firstTime){
      pinMode(6, OUTPUT);      // sets the digital pin 6 as output
      motorOnState=false;
      digitalWrite(6, LOW);   // sets pin 6 low
      firstTime=false;
    }
    showTarget();
    myservo.detach();
    // Check if light sensor changes significantly.
    int reading1= CircuitPlayground.lightSensor();
    delay(250);
    int reading2= CircuitPlayground.lightSensor();
    if (reading2-reading1>40) { 
      Serial.println("Target hit!");
      motorOnState=!motorOnState; // flip state of motor
      digitalWrite (6,motorOnState); // output state to motor pin #6
      myservo.attach(12);
      myservo.write(120);
      contactHit(255,0,0);
      delay(250);
      myservo.write(0);
      delay(250);
    }
  }

  virtual void setup(){
    CircuitPlayground.redLED(LOW);
    firstTime=true;
    pinMode(6, OUTPUT);      // sets the digital pin 6 as output
    motorOnState=false;
    digitalWrite(6, LOW);   // sets pin 6 low
    myservo.detach(); // detach servo if attached 
  }
  
  virtual void modePress() {

  }
 
private:
  bool motorOnState;
  bool firstTime;
};


#endif
