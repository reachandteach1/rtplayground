#ifndef LIGHTTAG2_H
#define LIGHTTAG2_H

// This is like LightTag1 except that the target is only active at random intervals for only 1.5 seconds

#include "Demo.h"
#include <Servo.h>

RtTimer rtTimer1; //setup a timer

void setupLightTag2(){ 
  rtTimer1.rtset(random(2500,4000));
}

class LightTag2: public Demo {
public:
  LightTag2() { activeSensor=false; setupLightTag2(); }
  ~LightTag2() {}

  virtual void loop() {  
     if (firstTime){
        pinMode(6, OUTPUT);      // sets the digital pin 6 as output
        motorOnState=false;
        digitalWrite(6, LOW);   // sets pin 6 low
        firstTime=false;
    }
    if (activeSensor){ // check if sensor should be active
      if (rtTimer1.rtGetTime()>0){        
        showTarget();
        // Check if light sensor changes significantly.
        int reading1= CircuitPlayground.lightSensor();
        delay(250);
        int reading2= CircuitPlayground.lightSensor();
        if (reading2-reading1>40) {
          Serial.println("Target hit!");
          motorOnState=!motorOnState; // flip state of motor
          digitalWrite (6,motorOnState); // output state to motor pin #6
          myservo.attach(12);
          myservo.write(120);
          contactHit(255,0,0);
          delay(250);
          myservo.write(0);
          delay(250);
          myservo.detach();
        }        
      } else { // turn off target for a random time interval
        hideTarget();
        activeSensor= false;
        rtTimer1.rtset(random(2000,4500)); 
      }
    } else { // sensor is not active
      if (rtTimer1.rtGetTime()==0){ // make sensor active after random interval
        activeSensor= true;
        rtTimer1.rtset(1500); // set time that sensor will be active
      }     
    }
  }

  virtual void setup(){
    CircuitPlayground.redLED(LOW);
    firstTime=true;
    pinMode(6, OUTPUT);      // sets the digital pin 6 as output
    motorOnState=false;
    digitalWrite(6, LOW);   // sets pin 6 low
    myservo.detach(); // detach servo if attached 
  }
  
  virtual void modePress() {

  }

private:
  bool activeSensor;
  bool motorOnState;
  bool firstTime;
};


#endif
