#ifndef CONTACT_H
#define CONTACT_H

#include "Demo.h"
#include <Servo.h>
#define CAP_THRESHOLD   80 

Servo myservo;  // create servo object to control a servo

void contactHit(int r, int g, int b){
  Serial.println("Target hit!");
  for (uint8_t i=0;i<10;i++) {
    CircuitPlayground.setPixelColor(i,r,g,b);
  }
  for (int j=262; j<440;j=j+20) {
    CircuitPlayground.playTone(j, 50); delay(5);
  }
}

class Contact: public Demo {
public:
  Contact() { }
  ~Contact() {}

  virtual void loop() {
    CircuitPlayground.clearPixels();
    myservo.detach();
    // Check if pad #3 is touched.
    if (capButton(3)) {
      motorOnState=!motorOnState; // flip state of motor
      digitalWrite (6,motorOnState); // output state to motor pin #6
      myservo.attach(12);
      myservo.write(120);
      contactHit(255,0,0);
      delay(250);
      myservo.write(0);
      delay(250);
    }
  }

  virtual void setup(){
    CircuitPlayground.redLED(LOW);
    pinMode(6, OUTPUT);      // sets the digital pin 6 as output
    motorOnState=false;
    digitalWrite(6, LOW);   // sets pin 6 low
    myservo.detach(); // detach servo if attached
  }
  
  virtual void modePress() {

  }

private:
bool motorOnState;
int score;  
};


#endif
