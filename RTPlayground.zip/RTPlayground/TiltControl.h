#ifndef TILTCONTROL_H
#define TILTCONTROL_H

#include "Demo.h"
// Based on the Tilt Demo original code, this adds keyboard usb output to control external programs
// Particularly,the Scratch Robot Arm demo at https://scratch.mit.edu/projects/10607750/
// Tilt left and right for left and right arrows
// Tilt up and down for up and down arrows
// Left button is "A" key, Right button is "D" key
// Define range of possible acceleration values.
#define MIN_ACCEL -10.0
#define MAX_ACCEL 10.0
bool keyright, keyleft, keyup, keydown, leftb,rightb;

class TiltControl: public Demo {
public:
  TiltControl() { extData=false; }
  ~TiltControl() {}

  virtual void loop() {
    // Grab the acceleration for the current mode's axis.
    showMode(extData);
    float accelx=CircuitPlayground.motionX();
    float accely=CircuitPlayground.motionY();
 
    leftb=CircuitPlayground.leftButton();
    rightb=CircuitPlayground.rightButton();


    // Light up all the pixels the interpolated color.
    for (int i=0; i<10; ++i) {
      if (i==4 || i==5) { // down arrow
        if (accelx>5){
          CircuitPlayground.strip.setPixelColor(i, 255, 0, 0);
          keydown=true;
        } else {
          CircuitPlayground.strip.setPixelColor(i, 0, 0, 0);
          keydown=false;
        }
      }
      if (i==0 || i==9) {
        if (accelx<-4){ // up arrow
          CircuitPlayground.strip.setPixelColor(i, 255, 0, 0);
          keyup=true;
        } else {
          keyup=false;
          CircuitPlayground.strip.setPixelColor(i, 0, 0, 0);
        }
      }
      if (i==2) { // left arrow
        if (accely<-5){
          CircuitPlayground.strip.setPixelColor(i, 0, 255, 0);
          keyleft=true;
        } else {
          keyleft=false;
          CircuitPlayground.strip.setPixelColor(i, 0, 0, 0);
        }
      }
      if (i==7) { // right arrow
        if (accely>5){
          CircuitPlayground.strip.setPixelColor(i, 0, 255, 0);
          keyright=true;
        } else {
          keyright=false;
          CircuitPlayground.strip.setPixelColor(i, 0, 0, 0);
        }
      }
      if (i==1||i==3||i==6||i==8) { // left or right button pushed
        if (leftb||rightb){
          CircuitPlayground.strip.setPixelColor(i, 0, 0, 255);
        } else {
          CircuitPlayground.strip.setPixelColor(i, 0, 0, 0);
        }
      }
    }
    if (extData){ //check if data should be written to usb ext keyboard
      if (keyright){Keyboard.write(KEY_RIGHT_ARROW);}
      if (keyleft){Keyboard.write(KEY_LEFT_ARROW);}
      if (keyup){Keyboard.write(KEY_UP_ARROW);}
      if (keydown){Keyboard.write(KEY_DOWN_ARROW);}
      if (leftb) {Keyboard.write('A');}
      if (rightb) {Keyboard.write('D');}
      delay(15);
    }
    
    CircuitPlayground.strip.show();
    delay(5);    
  }

  virtual void setup(){
    //extData=false;
    showMode(extData);
  }

  virtual void modePress() {
    extData=!extData;
    showMode(extData);
  }

private:
  bool extData; // flag whether to dump data to keyboard usb or not
};

#endif
