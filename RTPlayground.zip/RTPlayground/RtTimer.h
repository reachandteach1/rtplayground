#ifndef RTTIMER_H
#define RTTIMER_H

// Create simple countdown timers which can be set, reset, read
// Usage:
//   RtTimer rtTimer1;
//   rtTimer1.rtset(target time in ms);
//   rtTimer1.rtGetTime(); // return countdown timer in ms; 0 if out of time
// Author: Derrick Kikuchi, Reach and Teach
class RtTimer {
public:
  static unsigned long currentTime;
  unsigned long timerVal;
  virtual RtTimer() {}
  virtual ~RtTimer() {}

  void rtset(unsigned long dur){ // pass duration in ms
    timerVal=dur+millis();
  }
  
  long rtGetTime() {
    long timeDiff=timerVal-millis();
    return (max(0,timeDiff));
  }
};


#endif
