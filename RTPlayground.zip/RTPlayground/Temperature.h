#ifndef TEMPERATURE_H
#define TEMPERATURE_H

#include "Demo.h"

//display temperature in Farenheight in 2 degree increments with colored LEDs indicating temperature range
// black: below 30; blue: 30 - 48; green: 50-68; yellow: 70-88; red: 90-108

class Temperature: public Demo {
public:
  Temperature() {  }
  ~Temperature() {}

  virtual void loop() {
    int currentTemp0=(int)round(CircuitPlayground.temperature()*1.8+18);
    int currentTemp=min(max(currentTemp0,30),108)-18; // clip current temperature between 30 and 108 - 18
    Serial.print("Temperature F: ");Serial.println(currentTemp0);
    for(int i=0; i<10; i++) {
      if (currentTemp>=90) {
        CircuitPlayground.strip.setPixelColor(i, 255,0,0); // red
      }
      if (currentTemp>=70 && currentTemp<90) {
        CircuitPlayground.strip.setPixelColor(i, 255,255,0); // yellow
      }
      if (currentTemp>=50 && currentTemp<70) {
        CircuitPlayground.strip.setPixelColor(i, 0,255,0); // green
      }
      if (currentTemp>=30 && currentTemp<50) {
        CircuitPlayground.strip.setPixelColor(i, 0,0,255); // blue
      }
      if (currentTemp<30) {
        CircuitPlayground.strip.setPixelColor(i, 0,0,0); // black/dark
      }   
      currentTemp= currentTemp+2;   
    }
    // Show all the pixels.
    CircuitPlayground.strip.show();
  }

  virtual void setup(){
    CircuitPlayground.redLED(LOW);
  }
  

  virtual void modePress() {
  }

private:
  
  
};


#endif
